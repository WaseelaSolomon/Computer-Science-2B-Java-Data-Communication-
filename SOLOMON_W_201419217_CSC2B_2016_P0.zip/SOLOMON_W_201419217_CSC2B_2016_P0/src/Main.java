import java.io.IOException;
import java.net.*;

/**
 * 
 * @author W Solomon 201419217
 *
 */
public class Main 
{

	public static void main(String[] args) 
	{
		//creating the socket variable
		Socket connection = null;
		
		//loop through each port number
		for(int i = 1; i < 65535; i++)
		{
			try 
			{
				//instantiate the socket
				connection = new Socket("127.0.0.1", i);
				
				//display the IP Address and the local port number if connected
				System.out.println("IP Adrress: " + Inet4Address.getLocalHost().getHostAddress() + " successfully connected to port: " + i);
			}
			catch(UnknownHostException e)
			{
				e.printStackTrace();	//print error
			}
			catch(IOException ex)
			{
				//print the port number and error message if not connected to port
				System.err.println("port: " + i + " cannot be connected to.");
			}
			finally
			{
				if (connection != null)
				{
					try 
					{
						connection.close();	//close the connection to the port
					} 
					catch (IOException e) 
					{
						e.printStackTrace();	//print error message
					}
				}
			}
		}
	}

}
