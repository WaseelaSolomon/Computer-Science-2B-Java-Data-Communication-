import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

//CLASS FOR RENDERING IMAGES TO PANEL
@SuppressWarnings("serial")
public class ImagePanel extends JPanel 
{
	//PAINT IMAGE
	private BufferedImage img;
	@Override
	
	//FUNCTION TO PAINT IMAGE TO COMPONENT
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(img, 0, 0, null);
	}

	//FUNCTION TO SET THE IMAGE TO BE PAINTED
	public void setImage(BufferedImage image)
	{
		this.img = image;
		this.repaint();
	}

}
