import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import javax.imageio.*;
import javax.swing.*;

//CLIENT CLASS
@SuppressWarnings("serial")
public class Client extends JFrame
{
	//VARIABLES
	private Socket			socket;
	private InputStream		in;
	private PrintWriter		pw;
	private BufferedReader	br;
	private JButton			btnList;
	private JButton			btnSend;
	private JButton			btnRetr;
	private ImagePanel		imgPanel;
	private JTextArea		List;

	//CONSTRUCTOR
	public Client()
	{
		try 
		{
			//ESTABLISH CONNECTIONS
			socket = new Socket("127.0.0.1", 7451);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			pw = new PrintWriter(socket.getOutputStream(), true);
		} 
		catch (IOException e2) 
		{
			e2.printStackTrace();
		}
		
		//SETUP GUI
		setTitle("User");
		btnList = new JButton("Get Image List");
		List = new JTextArea();

		imgPanel = new ImagePanel();

		btnSend = new JButton("Upload Image");
		btnRetr = new JButton("Retrieve Image");
		
		btnSend.setEnabled(false);
		
		JPanel WestPanel = new JPanel();
		WestPanel.setLayout(new BorderLayout());
		WestPanel.add(btnList, BorderLayout.NORTH);
		WestPanel.add(List, BorderLayout.CENTER);
		
		JPanel EastPanel = new JPanel();
		EastPanel.setLayout(new BorderLayout());
		EastPanel.add(btnRetr, BorderLayout.NORTH);
		EastPanel.add(imgPanel, BorderLayout.CENTER);

		JPanel CenterPanel = new JPanel();
		CenterPanel.setLayout(new BorderLayout());
		CenterPanel.add(btnSend, BorderLayout.NORTH);

		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 3));
		panel.add(WestPanel);
		panel.add(CenterPanel);
		panel.add(EastPanel);

		add(panel, BorderLayout.CENTER);

		//LIST IMAGES FROM SERVER FILE
		btnList.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				try 
				{	
					String response;
					
					//REQUEST LIST FROM SERVER
					pw.println("LIST");
					response = br.readLine();
					List.append(response);	//RENDER LIST RECEIVED
					
				} 
				catch (IOException e1) 
				{
					e1.printStackTrace();
				}
			}
		});

		//SEND IMAGE TO SERVER
		btnSend.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				//CHOOSE FILE FROM PC
				int rtnVal = 0;
				JFileChooser ch = new JFileChooser();
				ch.showOpenDialog(Client.this);
				if(rtnVal == JFileChooser.APPROVE_OPTION)
				{
					File img = ch.getSelectedFile();
					try 
					{
						//SEND SELECTED FILE TO SERVER
						int imgToSave;
						FileInputStream file = new FileInputStream(img.getPath());
						DataOutputStream out = new DataOutputStream(socket.getOutputStream());
					 
						//SEND FILE BYTES TO SERVER
					    byte[] readData = new byte[1024]; 

	                    while((imgToSave = file.read(readData)) != -1) 
	                    { 
	                            out.write(readData, 0, imgToSave); 
	                    } 
					} 
					catch (FileNotFoundException e1) 
					{
						e1.printStackTrace();
					}
					catch (IOException e1) 
					{
						e1.printStackTrace();
					}
				}
			}
		});

		//RETRIEVE IMAGE FROM SERVER
		btnRetr.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e)
			{
				BufferedImage img = null;
				try 
				{
					//GET NAME OF IMAGE TO BE RETRIEVED
					String Name = JOptionPane.showInputDialog(Client.this, "Image Name", "Example: koko");
					
					//REQUEST SPECIFIC IMAGE FROM SERVER
					pw.println("RET " + Name);

					try
					{
						//READ IN IMAGE 
						in = socket.getInputStream();
						img = ImageIO.read(in);
						ClearRemainingSpace(in);
					}
					catch (IOException ex)
					{
						ex.printStackTrace();
					}
				}
				finally
				{
					imgPanel.setImage(img);	//RENDER IMAGE TO PANEL
				}
			}
		});
	}
	
	//FUNCTION TO CLEAR THE REMAINING BYTES FROM STREAM
	public static void ClearRemainingSpace(InputStream in)
	{
		int rem;
		try 
		{
			rem = in.available();	//IF THERE ARE BYTES TO CLEAR
			if (rem > 0)
			{
				byte[] trash = new byte[rem];	//REMOVE BYTES FROM STREAM
				in.read(trash);
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

	//FOR RUNNING THE CLIENT
	public static void main(String[] args)
	{
		//SET THE GUI FOR USER
		Client client = new Client();
		client.setSize(5000, 900);
		client.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		client.setLocationRelativeTo(null);
		client.setVisible(true);
		
	}
}
