import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;

//THIS CLASS WILL BE FOR THE SERVER 
public class Main 
{
	
	//VARIABLES
	static ServerSocket server = null;
	static File list = null;

	public static void main(String[] args) 
	{	
		try
		{
			//SETUP SERVER
			server = new ServerSocket(7451);
			System.out.println("Waiting");
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		
		do
		{
			run();
		}while(true);
	}
	
	public static void run()
	{
		//CLIENT SOCKET
		Socket socket = null;
		
		try
		{
			socket = server.accept();	//ACCEPT CLIENT CONNECTIONS
			
			//IO STREAMS
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
			OutputStream out = socket.getOutputStream();
			
			while(true)
			{
				//READ CLIENT REQUEST AND PROCESS IT
				String msg = in.readLine();
				
				StringTokenizer token = new StringTokenizer(msg, " ");	//to split the client question string
				
				String cmd = token.nextToken();
				
				switch(cmd)
				{
					//CLIENT REQUESTED LIST
					case "LIST":
						//READ LIST
						String[] imgList = getList();
						String con = "";
						
						//SEND EACH LINE IN LIST FILE TO CLIENT
					for(String line : imgList)
						{
						    con += line + "\t";
						}
					pw.println(con);
						break;
						
						//CLIENT REQUESTED RET
					case "RET":
						//RETRIEVE IMAGE FILE AND SEND IT TO CLIENT
						BufferedImage img = null;
						try
						{
							img = ImageIO.read(new File("docs/server_files/" + token.nextToken() + ".jpg")); //GETTING IMAGE FILENAME
						}
						catch (IOException ex)
						{
							ex.printStackTrace();
						}
						finally
						{
							ImageIO.write(img, "BMP", out);	//SEND IMAGE TO CLIENT
						}
						break;
						
						default:
							//CLIENT REQUESTED SEND
							
							//READ IMAGE FROM CLIENT AND WRITE IT TO FILE
							DataInputStream In = new DataInputStream(socket.getInputStream());
				            int i;
				            FileOutputStream Out = new FileOutputStream("image.jpg");
				            while ( (i = In.read()) > -1) 
				            {
				                Out.write(i);	//WRITE IMAGE 
				            }

				            Out.flush();
				}
			}
			
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	//FUNCTION TO READ LIST FILE CONTENTS
	public static String[] getList()
	{
		String[] contents = new String[3];
		list = new File("docs/server_files/List.txt");
		Scanner sc = null;
		
		try
		{
			sc = new Scanner(list);
			String ListLine = "";
			int count = 0;
			
			//READ CONTENTS
			while (sc.hasNext())
			{
				ListLine = sc.nextLine();
				contents[count] = ListLine;
				count++;
			}
		}
		catch (FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (sc != null) sc.close();
		}
		return contents;
	}

}
