package za.ac.uj.acsse.csc2b.pta.server;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * @author 201419217
 */
public class POSTITHandler implements Runnable
{
	//Variables
	PrintWriter writer;
	BufferedReader reader;
	BufferedOutputStream out;
	BufferedInputStream in;
	ArrayList<String> users = new ArrayList<>();
	
	//constructor
	public POSTITHandler(Socket newConnectionToClient)
	{
		try 
		{
			//setup streams
			out = new BufferedOutputStream(newConnectionToClient.getOutputStream());
			writer = new PrintWriter(out);
			reader = new BufferedReader(new InputStreamReader(newConnectionToClient.getInputStream()));
			in = new BufferedInputStream(newConnectionToClient.getInputStream());
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

	@Override
	public void run()
	{
		boolean running = true;
		
		while(running)
		{
			try 
			{
				//read request
				String line = reader.readLine();
				String[] lineSeg = line.split(" ");
				
				if(lineSeg.length < 1)
				{
					sendResponse("&ERR No Request Sent");	//no request
				}
				else if(lineSeg[0].equals("REG"))	//register 
				{
					if(lineSeg.length < 3)
					{
						sendResponse("&ERR No Name and/or Password");
					}
					else
					{
						//use function to register a user
						boolean succ = register(lineSeg[1], lineSeg[2]);
						if(succ)
						{
							//user was registered
							sendResponse("#OK User was registered!");
							
							//make a folder for user
							File userPost = new File("data/server/" + lineSeg[1]);
							if (!userPost.exists()) 
							{
							   userPost.mkdir();
							}
						}
						else
						{
							//user could not be registered
							sendResponse("&ERR User not be registered!");
						}
					}
				}
				else if(lineSeg[0].equals("LOGIN"))	//login
				{
					if(lineSeg.length < 3)
					{
						sendResponse("&ERR No Name and/or Password");
					}
					else
					{
						//use function to see if user exists
						boolean succ = authenticate(lineSeg[1], lineSeg[2]);
						if(succ)
						{
							//user logged in successfully
							sendResponse("#OK User logged on!");
							users.add(lineSeg[1]);	//add user to arraylist of online users
						}
						else
						{
							//user could not log in
							sendResponse("&ERR Could not login!");
						}
					}
				}
				else if(lineSeg[0].equals("POST"))	//post
				{
					if(lineSeg.length < 3)
					{
						sendResponse("&ERR No Title and/or Message");
					}
					else
					{
						PrintWriter writeFile = new PrintWriter(new BufferedWriter(new FileWriter("data/server/" + users.get(0) + "/" + lineSeg[1] +".txt", true)));
						
						int max = lineSeg.length - 1;
						
						for(int i = 2; i < max; i++)
						{
							writeFile.print(lineSeg[i] + " ");
						}
						writeFile.flush();
						writeFile.close();
						
						FileInputStream fis = new FileInputStream("data/client/" + lineSeg[lineSeg.length-1]);
						
						byte[] buffer = new byte[fis.available()];
						fis.read(buffer);
						fis.close();
						
						File img = new File("data/server/" + users.get(0) + "/" + lineSeg[1] +".jpg");
						FileOutputStream fos = new FileOutputStream(img);
						
						fos.write(buffer);
						fos.flush();
						fos.close();

						sendResponse("#OK Post was saved!");
					}
				}
				else if(lineSeg[0].equals("LOGOFF"))	//logoff
				{
					users.clear();	//remove online user
					sendResponse("#OK Goodbye User!");
				}
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			
		}
	}

	/**
	 * function to check if user name and password exist 
	 * @param name: user name
	 * @param password: user password
	 * @return: true if match found
	 */
	private boolean authenticate(String name, String password)
	{
		//go through file
		boolean found = false;
		Scanner userFileScanner = null;
		
		try
		{
			File users = new File("data/server", "users.txt");

			userFileScanner = new Scanner(users);
			while (userFileScanner.hasNext() && !found)
			{
				String user = userFileScanner.nextLine();
				//if user exists
				if (user.contains(name) && user.contains(password))
				{
					found = true;
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		
		return found;
	}

	private boolean register(String name, String password)
	{
		boolean success = false;
		PrintWriter usersOut = null;
		Scanner userFileScanner = null;
		try
		{

			File users = new File("data/server", "users.txt");

			boolean found = false;

			userFileScanner = new Scanner(users);
			while (userFileScanner.hasNext() && !found)
			{
				String user = userFileScanner.nextLine();
				if (user.contains(name))
				{
					found = true;
				}
			}
			if (!found)
			{
				String attempt = String.format("%s\t%s", name, password);
				usersOut = new PrintWriter(new FileWriter(users, true));
				usersOut.println(attempt);
				success = true;
			}
		}
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			if (usersOut != null) usersOut.close();
			if (userFileScanner != null) userFileScanner.close();
		}
		return success;
	}
	
	/**
	 * function to write responses to the clients
	 * @param response: text to send to client as response
	 */
	private void sendResponse(String response)
	{
		//send server response to client
		writer.println(response);
		writer.flush();
	}

	/**
	* The code below is to fix problems with ImageIO.read not clearing all bytes of an image.
	*/
	private static void clearInput(InputStream is) throws IOException
	{
		int extra = is.available();
		if (extra > 0)
		{
			byte[] buffer = new byte[extra];
			is.read(buffer);
			System.out.println(extra + " " + new String(buffer));
		}
	}

}
