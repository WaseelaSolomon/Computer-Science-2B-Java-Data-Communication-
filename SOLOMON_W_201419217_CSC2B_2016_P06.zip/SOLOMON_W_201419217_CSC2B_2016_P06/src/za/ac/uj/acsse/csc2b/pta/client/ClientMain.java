
package za.ac.uj.acsse.csc2b.pta.client;

import javax.swing.JFrame;

/**
 * @author 201419217
 */
public class ClientMain
{

	public static void main(String[] args)
	{
		//create new jframe
		POSTITClientFrame clientFrame= new POSTITClientFrame();
		//set the size of the frame
		clientFrame.setSize(1000, 700);
		clientFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		clientFrame.setLocationRelativeTo(null);
		clientFrame.setVisible(true);
	}
}
