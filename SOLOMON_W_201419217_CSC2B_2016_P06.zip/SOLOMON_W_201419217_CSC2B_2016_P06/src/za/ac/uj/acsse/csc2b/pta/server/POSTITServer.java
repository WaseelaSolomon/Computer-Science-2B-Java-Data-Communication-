package za.ac.uj.acsse.csc2b.pta.server;

import java.io.IOException;
import java.net.*;

/**
 * @author 201419217
 */
public class POSTITServer
{
	//variables
	ServerSocket listener = null;
	Socket clientSocket = null;
	
	public POSTITServer(int port)
	{
		//listen on port 2015
		try
		{
			listener = new ServerSocket(2015);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}

	/**
	 * 
	 */
	public void start()
	{
		//listen for client connections
		try 
		{
			clientSocket = listener.accept();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		//handle multiple clients
		Thread t = new Thread(new POSTITHandler(clientSocket));
		t.start();
	}

}
