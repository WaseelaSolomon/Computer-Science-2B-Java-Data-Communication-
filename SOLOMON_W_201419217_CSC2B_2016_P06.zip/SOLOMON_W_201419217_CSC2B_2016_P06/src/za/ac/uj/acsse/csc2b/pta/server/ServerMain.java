package za.ac.uj.acsse.csc2b.pta.server;

/**
 * @author 201419217
 */
public class ServerMain
{
	public static void main(String[] args)
	{
		POSTITServer server = new POSTITServer(2015);
		server.start();
	}

}
