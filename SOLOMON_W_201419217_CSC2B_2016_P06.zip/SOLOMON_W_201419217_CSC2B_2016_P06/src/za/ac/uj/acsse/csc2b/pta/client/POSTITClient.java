package za.ac.uj.acsse.csc2b.pta.client;

import java.io.*;
import java.net.*;

/**
 * @author 201419217
 */
public class POSTITClient
{
	//variables
	Socket socket = null;
	PrintWriter writer;
	BufferedReader reader;
	BufferedInputStream in;
	BufferedOutputStream out;
	
	public POSTITClient()
	{
		//connect to server on port 2015
		try
		{
			socket = new Socket("127.0.0.1", 2015);
			
			writer = new PrintWriter(socket.getOutputStream());
			in = new BufferedInputStream(socket.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in));
			out = new BufferedOutputStream(socket.getOutputStream());
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}

	/**
	 * function to send requests to the server
	 * @param message: request to be sent
	 */
	public void sendMessage(String message)
	{
		//write request to server
		writer.println(message);
		writer.flush();
	}

	/**
	 * function to read server responses
	 * @return: server response message
	 */
	public String getResponse()
	{
		//store response in a string variable
		String line = "";
		try 
		{
			line = reader.readLine();	//read server response
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return line;	//return the response
	}
}
