package za.ac.uj.acsse.csc2b.pta.client;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;

import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * @author 201419217
 */
@SuppressWarnings("serial")
public class POSTITClientFrame extends JFrame
{
	//variables
	POSTITClient client = null;
	JButton btnLogin, btnReg, btnPost, btnLogout;
	JTextField Name, Password, regName, regPass, Title, msg;
	JPanel Login, Reg, Post, Logout, LogDetails, RegDetails, PostDetails, panel;
	JLabel lblName, lblPassword, lblRegName, lblRegPass, lblTitle, lblMessage;
	
	public POSTITClientFrame()
	{
		//set up panels
		client = new POSTITClient();
		panel = new JPanel(new GridLayout(1,4));
		Login = new JPanel(new BorderLayout());
		Reg = new JPanel(new BorderLayout());
		Post = new JPanel(new BorderLayout());
		Logout = new JPanel(new BorderLayout());
		LogDetails = new JPanel(new GridLayout(3,2));
		RegDetails = new JPanel(new GridLayout(3,2));
		PostDetails = new JPanel(new GridLayout(3,2));
		
		//set up register panel
		lblName = new JLabel("Name: ");
		lblPassword = new JLabel("Password: ");
		Name = new JTextField(24);
		Password = new JTextField(24);
		btnLogin = new JButton("Log In");
		
		//set up login panel
		lblRegName = new JLabel("Name: ");
		lblRegPass = new JLabel("Password: ");
		regName = new JTextField(24);
		regPass = new JTextField(24);
		btnReg = new JButton("Register");
		
		//set up post panel
		lblTitle = new JLabel("Title: ");
		lblMessage = new JLabel("Message: ");
		Title = new JTextField(24);
		msg = new JTextField(100);
		btnPost = new JButton("Post Message");
		
		//set up logout button
		btnLogout = new JButton("Logout");
		
		//add to respective panels
		LogDetails.add(lblName);
		LogDetails.add(Name);
		LogDetails.add(lblPassword);
		LogDetails.add(Password);
		
		RegDetails.add(lblRegName);
		RegDetails.add(regName);
		RegDetails.add(lblRegPass);
		RegDetails.add(regPass);
		
		PostDetails.add(lblTitle);
		PostDetails.add(Title);
		PostDetails.add(lblMessage);
		PostDetails.add(msg);
		
		LogDetails.add(btnLogin);
		RegDetails.add(btnReg);
		PostDetails.add(btnPost);
		
		btnPost.setEnabled(false);	//false as no user logged in yet
		
		Login.add(LogDetails, BorderLayout.NORTH);
		Reg.add(RegDetails, BorderLayout.NORTH);
		Post.add(PostDetails, BorderLayout.NORTH);
		Logout.add(btnLogout, BorderLayout.NORTH);
		
		panel.add(Reg);
		panel.add(Login);
		panel.add(Post);
		panel.add(Logout);
		
		add(panel); //add panels to frame
		
		//register button
		btnReg.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				//send register request to server
				String req = "REG " + regName.getText() + " " + regPass.getText();
				client.sendMessage(req);
				
				//display server response
				System.out.println(client.getResponse());
				
				//clear text fields
				regName.setText("");
				regPass.setText("");
			}
			
		});
		
		btnLogin.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				//send register request to server
				String req = "LOGIN " + Name.getText() + " " + Password.getText();
				client.sendMessage(req);
				
				//display server response
				String response = client.getResponse();
				System.out.println(response);
				
				//if user log in successful
				if(response.equals("#OK User logged on!"))
				{
					btnPost.setEnabled(true);
				}
				
				//clear text fields
				Name.setText("");
				Password.setText("");
			}
			
		});
		
		btnPost.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				JFileChooser chooser = new JFileChooser("data/client");
				int result = chooser.showOpenDialog(POSTITClientFrame.this);
				
				if (result == JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = chooser.getSelectedFile();
					try 
					{
						File writeFile = new File(selectedFile.getAbsolutePath());
						FileInputStream fis = new FileInputStream(writeFile);
						byte[] buffer = new byte[fis.available()];
						fis.read(buffer);
						fis.close();
						
						String req = "POST " + Title.getText() + " " + msg.getText() + " " + selectedFile.getName();
						client.sendMessage(req);
						
						//client.out.write(buffer);
						//client.out.flush();
					} 
					catch (FileNotFoundException e1) 
					{
						e1.printStackTrace();
					} catch (IOException e1) 
					{
						e1.printStackTrace();
					}
				}
				
				
				System.out.println(client.getResponse());
				Title.setText("");
				msg.setText("");
			}
			
		});
		
		//logout button
		btnLogout.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				//send request to server
				String req = "LOGOFF";
				client.sendMessage(req);
				
				btnPost.setEnabled(false);	//disable the post button
				
				//read server response
				System.out.println(client.getResponse());
			}
			
		});

	}
}
