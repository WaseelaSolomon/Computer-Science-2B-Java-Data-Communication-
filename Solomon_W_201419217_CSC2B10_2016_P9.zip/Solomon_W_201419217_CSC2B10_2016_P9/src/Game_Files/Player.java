package Game_Files;

//IMPORTS
import java.awt.Point;

/**
 * This class will represent the 'player' in the game world
 * @author W Solomon - 201419217
 *
 */
public class Player extends GameWorld
{
	//CONSTRUCTOR
	public Player(Point p) 
	{
		super(p);
	}

}
