package Game_Files;

//IMPORTS
import java.awt.Point;

/**
 * This class will represent the 'Beacon' in the game world
 * @author W Solomon - 201419217
 *
 */
public class Beacon extends GameWorld
{
	//CONSTRUCTOR
	public Beacon(Point p) 
	{
		super(p);
	}

}
