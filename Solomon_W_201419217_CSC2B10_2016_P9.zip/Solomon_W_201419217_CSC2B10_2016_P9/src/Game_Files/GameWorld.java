package Game_Files;

//IMPORTS
import java.awt.Point;

/**
 * This class is the superclass for all game world objects
 * @author W Solomon - 201419217
 *
 */
public class GameWorld 
{
	//point to store the object's exact location
	protected Point co_ords;
	
	//CONTRUCTOR
	public GameWorld(Point p)
	{
		co_ords = p;
	}
	
	/**
	 * getter function to return the object's co-ordinates
	 * @return the object's x and y co-ordinates
	 */
	public Point getCo_ords()
	{
		return co_ords;
	}
	
	/**
	 * setter function to set the object's co-ordinates
	 * @param p the Point containing the object's co-ordinates
	 */
	public void setCo_ords(Point p)
	{
		co_ords = p;
	}
}
