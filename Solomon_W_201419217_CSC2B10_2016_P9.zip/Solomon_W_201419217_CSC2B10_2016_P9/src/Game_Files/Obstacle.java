package Game_Files;

//IMPORTS
import java.awt.Point;

/**
 * This class will represent the 'obstacles' in the game world
 * @author W Solomon - 201419217
 *
 */
public class Obstacle extends GameWorld
{
	//CONSTRUCTOR
	public Obstacle(Point p) 
	{
		super(p);
	}

}
