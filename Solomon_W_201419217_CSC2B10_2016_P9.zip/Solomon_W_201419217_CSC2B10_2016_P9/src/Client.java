
//ALL IMPORTED LIBRARIES
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

//IMPORTED CLASS
import GUI_Files.ImagePanel;

//CLIENT CLASS
@SuppressWarnings("serial")
/**
 * This is the client which will handle the creation of the gameworld
 * and other client/server functionality
 * @author W Solomon - 201419217
 *
 */
public class Client extends JFrame
{
	//VARIABLES
	private Socket socket;
	private PrintWriter pw;
	private BufferedReader br;
	public static ImagePanel imgPanel;	//custom panel to render gameworld
	private JButton btnSend;	//button to send the score to the server
	public static JTextArea msgs;	//textarea to display server messages

	//CONSTRUCTOR
	public Client()
	{
		try 
		{
			//SETUP CONNECTIONS AND STREAMS
			socket = new Socket("127.0.0.1", 5555);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			pw = new PrintWriter(socket.getOutputStream(), true);
		} 
		catch (IOException e2) 
		{
			e2.printStackTrace();
		}
		
		//SETUP GAME'S GUI
		setTitle("Demon Smash Race");
		
		//CREATE THE COMPONENTS
		imgPanel = new ImagePanel();
		btnSend = new JButton("Done!");
		msgs = new JTextArea();
		
		//SETUP THE COMPONENTS' LAYOUT
		msgs.setFocusable(false);	//set the textarea focusable attribute to false so that the game panel has focus
		JPanel panel = new JPanel();	//panel to hold all components
		panel.setLayout(new BorderLayout());
		panel.add(imgPanel, BorderLayout.CENTER);
		panel.add(btnSend, BorderLayout.SOUTH);
		panel.add(msgs, BorderLayout.NORTH);

		//ADD THE PANEL TO THE FRAME
		add(panel, BorderLayout.CENTER);
		
		//EVENT-HANDLER FOR THE btnSend BUTTON
		btnSend.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				//SEND THE SCORE PROTOCOL MESSAGE AS WELL AS THE PLAYER SCORE AND USERNAME
				String Name = JOptionPane.showInputDialog(Client.this, "Enter A Username:");
				pw.println("SCORE " + ImagePanel.TimeScore + " " + Name + " - ");
				pw.flush();
			}
		});
		
		//INSTANTIATE THE RUNNABLE serverMsgs CLASS AND ADD TO THREAD TO CONTINUOUSLY RECEIVE SERVER MSGS
		serverMsgs server = new serverMsgs(br);
		Thread t = new Thread(server);
		t.start();
	}

	//FOR RUNNING THE CLIENT
	public static void main(String[] args)
	{
		//CREATE THE GUI FOR USER
		Client client = new Client();
		client.setSize(616, 679);
		client.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		client.setLocationRelativeTo(null);
		client.setVisible(true);
	}
}

/**
 * This class is used to continuously receive server messages
 * @author W Solomon - 201419217
 *
 */
class serverMsgs implements Runnable
{
	//VARIABLES
	BufferedReader in;
	
	//CONSTRUCTOR
	public serverMsgs(BufferedReader in)
	{
		this.in = in;
	}
	
	//RUN FUNCTION
	@Override
	public void run() 
	{
		while(true)
		{
			try 
			{
				if(in.ready())	//if there is something to be read from the stream
				{
					//read the msg from server and display it on the text area above the game world
					String response = in.readLine();
					Client.msgs.append(response);
				}
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
}