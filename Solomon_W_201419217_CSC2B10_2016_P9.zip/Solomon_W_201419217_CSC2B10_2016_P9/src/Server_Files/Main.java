package Server_Files;

//IMORTS
import java.net.*;

/**
 * class to create and start the server
 * @author W Solomon - 201419217
 *
 */
public class Main 
{
	
	//VARIABLES
	static ServerSocket server = null;
	static Socket socket = null;

	public static void main(String[] args) 
	{	
		//run the server and listen on port 5555
		Server server = new Server(5555);
		server.start();
	}
	
	
}