package Server_Files;

//ALL IMPORTED CLASSES
import java.io.*;
import java.net.*;

/**
 * class to handle client requests
 * @author W Solomon - 201419217
 *
 */
public class Handler implements Runnable
{
	//VARIABLES
	PrintWriter writer;
	BufferedReader reader;
	BufferedOutputStream out;
	BufferedInputStream in;
		
	//CONSTRUCTOR
	public Handler(Socket newConnectionToClient) 
	{
		try 
		{
			//SETUP STREAMS
			out = new BufferedOutputStream(newConnectionToClient.getOutputStream());
			writer = new PrintWriter(out);
			reader = new BufferedReader(new InputStreamReader(newConnectionToClient.getInputStream()));
			in = new BufferedInputStream(newConnectionToClient.getInputStream());
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	//THE RUN FUNCTION
	@Override
	public void run() 
	{
		boolean running = true;
		
		while(running)
		{
			try
			{
				//READ CLIENT REQUESTS
				String line = reader.readLine();
				String[] lineSeg = line.split(" ");

				if(lineSeg.length < 1)
				{
					//SEND ERROR MESSAGES IF INCORRECT PROTOCOL USED
					writer.println("ERROR No Request Received");	//no request
				}
				else if(lineSeg[0].equals("SCORE"))
				{
					if(lineSeg[2].length() > 0)
					{
						Server.users.add(new User());//create a new user/player
						Server.count++;	//keep track of # of players
						
						//SET THE USERNAME AND SCORE FOR THE NEW PLAYER
						Server.users.get(Server.count-1).setScore(Integer.parseInt(lineSeg[1]));
						Server.users.get(Server.count-1).setUsername(lineSeg[2]);
						
						//SEND THE PLAYER NAME AND SCORE TO THE CLIENT
						writer.println("UPDATE Player: " + lineSeg[2] + " Score: " + Server.users.get(Server.count-1).score + " -> ");
						
						if(Server.users.size() >= 2)	//check if more than one player currently playing
						{	
							//--CALCULATE AND SEND THE WINNER DETAILS TO THE CLIENTS--//
							
							//NOTE: this doesn't work completely 100%, the problem i've come across is that only one
							//client will receive this information, not both//
							if(Server.users.get(0).score == Server.users.get(1).score)
							{
								writer.println("DRAW!");
								writer.flush();
							}
							else if(Server.users.get(0).score < Server.users.get(1).score)
							{
								writer.println("WINNER - Player: " + Server.users.get(0).username + " wins!");
								writer.flush();
							}
							else
							{
								System.out.println("WINNER - Player: " + Server.users.get(1).username + " wins!");
								writer.flush();
							}
						}
					}
					else
					{
						//SEND ERROR MESSAGES IF INCORRECT PROTOCOL USED
						writer.println("ERROR No Username Received");	//no request
					}
				}

			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
