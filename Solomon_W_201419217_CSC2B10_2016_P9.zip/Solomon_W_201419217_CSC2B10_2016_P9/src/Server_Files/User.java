package Server_Files;

//IMPORTS
import java.io.Serializable;

@SuppressWarnings("serial")
/**
 * class to store all client-player information
 * @author W Solomon - 201419217
 *
 */
public class User implements Serializable
{
	//VARIABLES
	String username;
	int score;
	
	//CONSTRUCTOR
	public User() 
	{
		score = 0;
	}
	
	/**
	 * setter function to set the player's username
	 * @param username username specified by the player
	 */
	public void setUsername(String username)
	{
		this.username = username;
	}
	
	/**
	 * setter function to set the score each player acquired
	 * @param score score as send via the client
	 */
	public void setScore(int score)
	{
		this.score = score;
	}
}
