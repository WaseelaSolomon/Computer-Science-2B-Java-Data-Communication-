package Server_Files;

//ALL IMPORTED LIBRARIES
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class will handle the setting up of the server 
 * @author W Solomon - 201419217
 *
 */
public class Server 
{
	//VARIABLES
	ServerSocket listener = null;
	Socket clientSocket = null;
	public static ArrayList<User> users = new ArrayList<>();
	public static int count;
	
	//CONSTRUCTOR
	public Server(int port) 
	{
		try
		{
			listener = new ServerSocket(port);	//create the server and listen on port specified
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	/**
	 * function to connect to client sockets and handle multiple game sessions
	 */
	public void start()
	{
		while(true)
		{
			try 
			{
				clientSocket = listener.accept();	//accept connection from socket
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
			
			//handle multiple clients - game sessions
			Thread t = new Thread(new Handler(clientSocket));
			t.start();
		}
		
	}
}
