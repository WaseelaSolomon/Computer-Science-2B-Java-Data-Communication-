package GUI_Files;

//ALL IMPORTED LIBRARIES
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//IMPORTED CLASSES
import Game_Files.*;

@SuppressWarnings("serial")
/**
 * This is the class used to render the gameworld onto a panel for the GUI
 * @author W Solomon - 201419217
 *
 */
public class ImagePanel extends JPanel implements KeyListener, ActionListener
{
	//GAME VARIABLES
	Image player, beacon, obstacle, tile;
	private static int tileSize = 50;
	Graphics g;
	Player playerObj;
	public static boolean win = false;
	
	//GAME VARIABLES TO KEEP TRACK OF TIME
	static long gameBegin = System.currentTimeMillis();
	public static int TimeScore;
	
	//2D ARRAY USED AS THE GAMEWORLD
	public GameWorld[][] world = null;
	
	//CONSTRUCTOR
	public ImagePanel()
	{
		//the following is to ensure that the GUI focuses on this panel
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		
		//create a player
		playerObj = new Player(new Point(11, 1));
		
		//initialize the world and the images used to display the world
		initIcons();
		initWorld();
	}
	
	/**
	 * function used to initialize the game world 2d array with the appropriate game objects
	 */
	public void initWorld()
	{
		world = new GameWorld[12][12];
		for(int r = 0; r < 12; r++)
		{
			for(int c = 0; c < 12;c++)
			{
				world[r][c] = new Tile(new Point(r,c));	//set the tiles for the game world
				
				if(r == 11 || r == 0 || c == 11 || c == 0)
				{
					world[r][c] = new Obstacle(new Point(r,c));	//set the boundaries of the game world
				}
			}
		}
		
		//place the player and the beacon in fixed places 
		world[11][1] = playerObj;
		world[5][10] = new Beacon(new Point(5,10));
	}
	
	/**
	 * function to initialize the image icons used to display the game world objects
	 */
	public void initIcons()
	{
		//set the blank tile image
		ImageIcon img = new ImageIcon("data/tile.png");
		tile = img.getImage();
		
		//set the player image
		img = new ImageIcon("data/player.png");
		player = img.getImage();
		
		//set the beacon image
		img = new ImageIcon("data/beacon.png");
		beacon = img.getImage();
		
		//set the obstacle/wall image
		img = new ImageIcon("data/obstacle.png");
		obstacle = img.getImage();
	}
	
	/**
	 * function to paint the panel
	 */
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		//go through the 2d gameworld array and paint each image/object onto a tile in the game
		for(int r = 0; r < 12; r++)
		{
			for(int c = 0; c < 12; c++)
			{
				if(world[r][c] instanceof Tile)
				{
					g.drawImage(tile, world[r][c].getCo_ords().x * tileSize, world[r][c].getCo_ords().y * tileSize, null);
				}else if(world[r][c] instanceof Beacon)
				{
					g.drawImage(beacon, world[r][c].getCo_ords().x * tileSize, world[r][c].getCo_ords().y * tileSize, null);
				}else if(world[r][c] instanceof Obstacle)
				{
					g.drawImage(obstacle, world[r][c].getCo_ords().x * tileSize, world[r][c].getCo_ords().y * tileSize, null);
				}else if(world[r][c] instanceof Player)
				{
					g.drawImage(player, world[r][c].getCo_ords().x * tileSize, world[r][c].getCo_ords().y * tileSize, null);
				}
			}
		}
	}

	
	//---THE KEY EVENTS---//
	
	@Override
	public void keyTyped(KeyEvent e) 
	{
	}

	@Override
	public void keyPressed(KeyEvent e) 
	{
		int keycode = e.getKeyCode();	//get the key code of the key pressed
		
		//check which key was pressed
		if(keycode == KeyEvent.VK_LEFT)
		{
			//move the player one cell to the left
			if(!(world[(playerObj.getCo_ords().x - 1)][(playerObj.getCo_ords().y)] instanceof Obstacle))
			{
				playerObj.setCo_ords(new Point(playerObj.getCo_ords().x - 1, playerObj.getCo_ords().y));
			}
			
			//check if the player has reached the beacon
			if(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y)] instanceof Beacon)
			{
				win = true;
			}
		}
		else if(keycode == KeyEvent.VK_UP)
		{
			//move the player one cell up
			if(!(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y - 1)] instanceof Obstacle))
			{
				playerObj.setCo_ords(new Point(playerObj.getCo_ords().x, playerObj.getCo_ords().y - 1));
			}
			
			//check if the player has reached the beacon
			if(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y)] instanceof Beacon)
			{
				win = true;
			}
			
		}
		else if(keycode == KeyEvent.VK_RIGHT)
		{
			//move the player one cell to the right
			if((playerObj.getCo_ords().x + 1) < 12)
			{
				if(!(world[(playerObj.getCo_ords().x + 1)][(playerObj.getCo_ords().y)] instanceof Obstacle))
				{
						playerObj.setCo_ords(new Point(playerObj.getCo_ords().x + 1, playerObj.getCo_ords().y));
					
				}
			}
			
			//check if the player has reached the beacon
			if(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y)] instanceof Beacon)
			{
				win = true;
			}
		}
		else if(keycode == KeyEvent.VK_DOWN)
		{
			//move the player one cell down
			if(!(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y + 1)] instanceof Obstacle))
			{
				playerObj.setCo_ords(new Point(playerObj.getCo_ords().x, playerObj.getCo_ords().y + 1));
			}
			
			//check if the player has reached the beacon
			if(world[(playerObj.getCo_ords().x)][(playerObj.getCo_ords().y)] instanceof Beacon)
			{
				win = true;
			}
		}
		
		//check if the player reached the beacon
		if(win == true)
		{
			//store the time taken by the player to reach the beacon 
			TimeScore = (int)(Math.round(((System.currentTimeMillis() - gameBegin) / 1000F)*100)/100);
		}
		repaint();	//repaint the panel
	}

	@Override
	public void keyReleased(KeyEvent e) 
	{
		
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		repaint();	//repaint the panel
	}
}