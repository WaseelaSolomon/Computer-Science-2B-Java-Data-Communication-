import java.io.*;
import java.net.*;
import java.util.Random;
import java.util.StringTokenizer;


public class Main 
{
	//variables needed to run server
	private static ServerSocket serv = null;
	private static final int PORT = 8888;
	
	public static void main(String[] args) 
	{
		//display "waiting for connections"
		System.out.println("Waiting for connections... \n");
		
		try
		{
			serv = new ServerSocket(PORT);	//bind server to port 8888
		}
		catch(IOException ex)
		{
			System.out.println("Unable to connect to the port!");
			System.exit(1);
		}
		
		do
		{
			run();	//run method call
		}while(true);
	}
	
	/**
	 * run method used to communicate from server to client
	 */
	public static void run()
	{
		Socket connection = null;
		try
		{
			connection = serv.accept();	//wait for client connection
			
			//variables for I/O streams
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			PrintWriter out = new PrintWriter(connection.getOutputStream(), true);
			
			//display "WELCOME - You may ask 5 questions"
			out.println("01 WELCOME - You may ask 5 questions");
			
			int numMessages = 0;	//count the number of questions asked
			String message = in.readLine();
			
			while(!message.equals("DONE"))
			{
				//random number generator
				Random randomGenerator = new Random();
				int randomInt = randomGenerator.nextInt(3) + 1;
				
				if(numMessages < 5)	//loop to control the max number of questions asked by client
				{
					out.println("02 ASK your question or DONE");//display "ASK your question or DONE"
					message = in.readLine();	//read question
					
					StringTokenizer token = new StringTokenizer(message, " ");	//to split the client question string
					
					String ask = token.nextToken();	
					
					if(ask.equals("ASK"))
					{
						String ques = token.nextToken();
						
						//provide appropriate response depending on question asked
						switch(ques)
						{
						case "ARE":
						case "are":
						case "Are":
							switch(randomInt)
							{
							case 1: 
								out.println("03 Yes.");
								break;
							case 2: 
								out.println("03 No.");
								break;
							case 3: 
								out.println("03 Maybe.");
								break;
							}
							break;
						case "WHY":
						case "why":
						case "Why":
							out.println("03 Because it's just like that.");
							break;
							default:
								switch(randomInt)
								{
								case 1: 
									out.println("03 42.");
									break;
								case 2: 
									out.println("03 Please try again later.");
									break;
								case 3: 
									out.println("03 Meh.");
									break;
								}
						}
					}else
					{
						numMessages--;	//wrong question format
						if(!message.equals("DONE"))
							out.println("Wrong question format. Format is -> ASK [Question].");
					}
				}
				else
				{
					//all questions asked, terminate connection to server
					out.println("05 GOODBYE " + numMessages + " questions answered.");
					System.exit(0);
				}
				numMessages++;
			}
			//client terminated connection to server
			out.println("04 GOODBYE " + numMessages + " questions answered.");
			System.exit(0);
		}
		catch(IOException e)
		{
			System.out.println("Unable to disconnect!");
			System.exit(1);
		}
	}

}
