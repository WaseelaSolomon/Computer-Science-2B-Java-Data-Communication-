import java.util.*;
import java.io.*;
import java.net.*;

public class ClientThread extends Thread
{
	//socket accepted by server
	private Socket connection;
	
	//set socket and start thread
	public ClientThread(Socket s) 
	{
	    connection = s;
	    start();
	}
	
	public void run() {
	    try {

	      // Establishing I/O streams
	      BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	      DataOutputStream out = new DataOutputStream(connection.getOutputStream());

	      //read input from socket
	      String clientreq = in.readLine();
	      
	      //tokenizer to split up the GET request command
	      StringTokenizer token = new StringTokenizer(clientreq);
	      
	      try 
	      {
			// Begin attempt to render index.html page
			String request = "";
	        //appending GET command to request variable
	        if (token.hasMoreElements() && token.nextToken().equalsIgnoreCase("GET") && token.hasMoreElements()) 
	        {
	        	request = token.nextToken();
	        }
			
			// get the html file from the docs folder
			if (request.endsWith("/"))
			{
				request += "docs/index.html";
			}
			  
			// Remove ending "/" from the requested filename
			while (request.indexOf("/") == 0)
			{
				request = request.replaceFirst("/", "");
			}
			
			//print 200 response code
	        System.out.print("HTTP/1.0 200 OK\r\n" + "\r\n\r\n");

	        //
	        InputStream input = new FileInputStream(request);

	        // Sending the contents of the file to the client
	        byte[] b = new byte[1024];
	        int contents;
	        
	        //render contents
	        while ((contents = input.read(b)) != -1)
	        {
	        	out.write(b, 0, contents);
	        }
	        
	        //close I/O streams
	        out.close();
	        input.close();
	      }
	      catch (FileNotFoundException e) 
	      {
	    	//print error 404 to client
	        out.writeBytes("HTTP/1.0 404 Not Found\r\n" + "Content-type: text/html\r\n\r\n" + "<html><head></head><body>" +  " not found</body></html>\n");
	        out.close();
	      }
	    }
	    catch (IOException ex) 
	    {
	      //print error 500
		  System.out.println("HTTP/1.0 500 Error occured\r\n" + "Content-type: text/html\r\n\r\n" + "<html><head></head><body>" + " something went wrong</body></html>\n");
	    }
	  }
}
