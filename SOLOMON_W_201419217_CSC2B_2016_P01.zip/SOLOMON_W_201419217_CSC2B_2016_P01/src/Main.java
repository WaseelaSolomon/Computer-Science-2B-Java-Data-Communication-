import java.io.*;
import java.net.*;

public class Main 
{
	//server socket variable
	public static ServerSocket s; 
	
	  public static void main(String[] args) 
	  {
	    try 
	    {
	    	//set server to listen on port 1337
			s = new ServerSocket(1337);
		} 
	    catch (IOException e) 
	    {
		} 
	    
	    while (true) 
	    {
	      try 
	      {
	    	//wait for and accept a client socket
	        Socket connection = s.accept(); 
	        new ClientThread(connection);  
	      }
	      catch (Exception ex) 
	      {
	      }
	    }
	  }
	}